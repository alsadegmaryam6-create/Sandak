plugins {
    id("com.android.application")
}

android {
    namespace = "com.daleel.sudan"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.daleel.sudan"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        create("release") {
            val ksPath = System.getenv("DALEEL_KEYSTORE_PATH")
            val ksPassword = System.getenv("DALEEL_KEYSTORE_PASSWORD")
            val ksAlias = System.getenv("DALEEL_KEY_ALIAS")
            val keyPasswordEnv = System.getenv("DALEEL_KEY_PASSWORD")
            if (!ksPath.isNullOrBlank()) {
                storeFile = file(ksPath)
                storePassword = ksPassword
                keyAlias = ksAlias
                keyPassword = keyPasswordEnv
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity:1.10.1")
}
