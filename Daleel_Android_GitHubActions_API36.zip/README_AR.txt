مشروع Android لتطبيق «دليلك»
============================

الرابط المستخدم داخل التطبيق:
https://alsadegmaryam6-create.github.io/Sandak/

الإعدادات:
- applicationId: com.daleel.sudan
- minSdk: 23
- targetSdk: 36
- compileSdk: 36
- versionCode: 1
- versionName: 1.0
- صلاحية INTERNET فقط.
- يدعم JavaScript وDOM Storage.
- يدعم اختيار الصور/الملفات من حقول HTML.
- الروابط الخارجية مثل واتساب تفتح بالتطبيق المناسب.
- زر الرجوع يرجع داخل صفحات WebView أولاً.

مهم قبل Google Play:
1) افتحي المشروع في Android Studio وثبتي Android SDK 36 إذا طُلب.
2) أضيفي أيقونة دليلك الرسمية عبر Image Asset.
3) أنشئي مفتاح توقيع خاص بك واحفظيه بأمان.
4) Build > Generate Signed App Bundle or APK > Android App Bundle.
5) راجعي سياسة الخصوصية وData safety وسياسة الدفع قبل الإرسال النهائي.

ملاحظة:
لم يتم تضمين مفتاح توقيع أو كلمات مرور داخل المشروع.

تمت إضافة أيقونة دليلك إلى مجلدات Android بالمقاسات القياسية، مع ملف 512x512 لمتجر Google Play.
